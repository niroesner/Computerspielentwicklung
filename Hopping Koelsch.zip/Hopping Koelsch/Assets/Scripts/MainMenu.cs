﻿using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine;

public class MainMenu : MonoBehaviour {

    private Transform cameraTransform;
    private Transform cameraDesiredLookAt;

    private void Start()
    {
        cameraTransform = Camera.main.transform;
    }

    public void LookAtMenu(Transform menuTransform)
    {
        //Camera.main.transform.LookAt(menuTransform.position);
        cameraDesiredLookAt = menuTransform;
    }

    private void Update()
    {
        if (cameraDesiredLookAt != null)
        {
            cameraTransform.rotation = Quaternion.Slerp(cameraTransform.rotation, cameraDesiredLookAt.rotation, 4 * Time.deltaTime);
        }
    }

    /* public class Loader : MonoBehaviour              funktion um zum menü zu kommen --> wirn in Lvlmanager erstellt
     {
         public void Stop()
         {
            Application.LoadLevel();

         }
     }
   public void LoadLevel(string level)
    {
        Application.LoadLevel(level);
    }*/
    public void Play()
    {
        SceneManager.LoadScene("frogger");
    }

    /*public class BackToMenu : MonoBehaviour
    {
        public void ToMenu()
        {
            SceneManager.LoadScene("Menu");
        }
    }*/

}

